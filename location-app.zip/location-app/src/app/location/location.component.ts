import { Component, OnInit } from '@angular/core';
import { DataAccessService } from '../data-access.service';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  constructor(private dataaccess:   DataAccessService) { }
 
  ngOnInit() {
  }
  getLocation(f: NgForm) {
   this.dataaccess.getCityCoordinates('http://www.datasciencetoolkit.org/maps/api/geocode/json?sensor=false&address='+ f.name).
   subscribe(locn => console.log(locn));
   //lat= locn.latitude
   //long= locn.longitude);
  }

}
